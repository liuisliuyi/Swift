//
//  WZHScrollHeaderView.swift
//  斗鱼
//
//  Created by 汪泽煌 on 2017/2/16.
//  Copyright © 2017年 汪泽煌. All rights reserved.
//

import UIKit



class WZHScrollHeaderView: UIView {
    
    
    override init(frame:CGRect){
        
        super.init(frame: frame)
        
        setupSubViews()
    }
    
    func setupSubViews(){
        self.backgroundColor = UIColor.white
        
    
    }
    
    convenience init(frame:CGRect,titleArr:Array<String>){
        self.init(frame:frame)
        
        let w =  UIScreen.main.bounds.size.width / (CGFloat)(titleArr.count)
        var count = 0
        
        
        for title:String in titleArr {
            
            print(title)
            let x = w * (CGFloat)(count)
            count += 1
            let lb_title = UILabel(frame: CGRect(x: x, y: 0, width: w, height: 40))
            lb_title.text = title
            lb_title.textAlignment = .center
            self.addSubview(lb_title)
//            let tap = UITapGestureRecognizer(target: self, action: #selector(tapClick(label: lb_title)))
            
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
