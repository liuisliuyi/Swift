//
//  DYHomeController.swift
//  斗鱼
//
//  Created by 汪泽煌 on 2017/2/14.
//  Copyright © 2017年 汪泽煌. All rights reserved.
//

import UIKit

class DYHomeController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = UIColor.white
        automaticallyAdjustsScrollViewInsets = false
        setupUI()
    
    }


}


// MARK: - 设置UI界面
extension DYHomeController{
    
    fileprivate func setupUI(){
        
        setupNav()
        setupHeaderView()
        
    }

    fileprivate func setupNav(){
        
        //设置导航栏左侧
        let leftBtnItem = UIButton()
        
        leftBtnItem.setImage(UIImage(named:"logo"), for: .normal)
        leftBtnItem.sizeToFit()
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: leftBtnItem)
        
        //设置导航栏右侧
        let size = CGSize(width: 40, height: 40)
        
        let historyItem = UIBarButtonItem(image: UIImage(named:"image_my_history")!, selectImage: UIImage(named:"Image_my_history_click")!, size: size)
        let searchItem = UIBarButtonItem(image: UIImage(named:"btn_search")!, selectImage: UIImage(named:"btn_search_clicked")!, size: size)
        let qrcodeItem = UIBarButtonItem(image: UIImage(named:"Image_scan")!, selectImage: UIImage(named:"Image_scan_click")!, size: size)
        
        navigationItem.rightBarButtonItems = [historyItem,searchItem,qrcodeItem]
    }
    
    fileprivate func setupHeaderView(){
        
//        let headerView = WZHScrollHeaderView(frame: CGRect(x: 0, y: 64, width: UIScreen.main.bounds.size.width, height: 40), titleArr: ["推荐","游戏","娱乐","趣玩"])
//        view.addSubview(headerView)
        
        let headerView = DYPageTitleView(frame: CGRect(x: 0, y: 64, width: UIScreen.main.bounds.size.width, height: 44), titles: ["推荐","游戏","娱乐","趣玩"])
//        headerView.backgroundColor = UIColor.purple
        view.addSubview(headerView)

    }
    
    fileprivate func setupContentView(){
        
        
    }
    
}
