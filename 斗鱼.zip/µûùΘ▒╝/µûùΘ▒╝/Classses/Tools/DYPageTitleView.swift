//
//  DYPageTitleView.swift
//  斗鱼
//
//  Created by 汪泽煌 on 2017/2/21.
//  Copyright © 2017年 汪泽煌. All rights reserved.
//

import UIKit

class DYPageTitleView: UIView {
    
    fileprivate var titles:[String]
    fileprivate var labels:[UILabel] = [UILabel]()
    fileprivate var scrollLine:UIView = UIView()
    fileprivate var selectedLabel = UILabel()

    fileprivate lazy var scrollView:UIScrollView = {
        
        let scrollView = UIScrollView(frame:self.bounds)
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.showsVerticalScrollIndicator = false
        return scrollView
    }()
    
    init(frame: CGRect,titles:[String]) {
        
        self.titles = titles
        
        super.init(frame: frame)
        
        setupUI()
    }
    
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}


// MARK: - 设置界面
extension DYPageTitleView{

    fileprivate func setupUI() {
        
        //添加scrollView
        addSubview(scrollView)
        scrollView.frame = bounds
        
        //向scrollView上添加label
        setupLabel()
        
        //向scrollView上添加lineview
        setupLineView()
        
        //添加下划线
        setupScrollLine()
    }
    
    fileprivate func setupLabel(){
        let labelY:CGFloat = 0
        let labelH:CGFloat = 44
        var labelW:CGFloat = kScreenW / CGFloat(titles.count)
        
        if labelW < 80 {
            labelW = 80
            scrollView.contentSize = CGSize(width: 80 * CGFloat(titles.count), height: 0)
        }

        for (index,title) in titles.enumerated(){
            let labelX:CGFloat = labelW * CGFloat(index)
            
            let label = UILabel()
            if index == 0 {
                label.textColor = UIColor.orange
                selectedLabel = label
            }
            label.tag = index + 10
            label.frame = CGRect(x: labelX, y: labelY, width: labelW, height: labelH)
            label.text = title
            label.textAlignment = .center
            scrollView.addSubview(label)
            
            labels.append(label)
            
            label.isUserInteractionEnabled = true
            let tap = UITapGestureRecognizer.init(target: self, action:#selector(tapClick(sender:)))
            label.addGestureRecognizer(tap)
            
        }
        
    }
    
    
    /// 私有函数的情况下需要使用 @objc,这样才能在方法选择器里面使用
    @objc fileprivate func tapClick(sender:UITapGestureRecognizer){
        
        print(sender.view!.tag)
        selectedLabel.textColor = UIColor.black
        let tapLabel = viewWithTag(sender.view!.tag) as! UILabel
        selectedLabel = tapLabel
        UIView.animate(withDuration: 0.15) {
            tapLabel.textColor = UIColor.orange
            self.scrollLine.frame = CGRect(x: tapLabel.frame.origin.x, y: 42, width: tapLabel.frame.size.width, height: 2)
        }
      
    }
    
    fileprivate func setupLineView(){
        let lineView = UIView()
        lineView.backgroundColor = UIColor.lightGray
        let lineViewW = scrollView.contentSize.width == 0 ? kScreenW : scrollView.contentSize.width
        
        lineView.frame = CGRect(x: -100, y: 43, width: lineViewW+200, height: 1)
        scrollView.addSubview(lineView)

    }
    
    fileprivate func setupScrollLine(){
        
        let lineW = labels.first!.frame.size.width
        
        scrollLine.frame = CGRect(x: 0, y: 42, width: lineW, height: 2)
        scrollLine.backgroundColor = UIColor.orange
        scrollView.addSubview(scrollLine)
        
    }
    
    
}


extension DYPageTitleView : UIScrollViewDelegate{
    

    
    
}
