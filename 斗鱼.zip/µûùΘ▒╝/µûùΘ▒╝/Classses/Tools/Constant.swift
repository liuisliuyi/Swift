//
//  Constant.swift
//  斗鱼
//
//  Created by 汪泽煌 on 2017/2/21.
//  Copyright © 2017年 汪泽煌. All rights reserved.
//

import UIKit


let kScreenW = UIScreen.main.bounds.size.width
let kScreenH = UIScreen.main.bounds.size.height


