//
//  DYLiveController.swift
//  斗鱼
//
//  Created by 汪泽煌 on 2017/2/14.
//  Copyright © 2017年 汪泽煌. All rights reserved.
//

import UIKit

class DYLiveController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = UIColor.green
    }



}
