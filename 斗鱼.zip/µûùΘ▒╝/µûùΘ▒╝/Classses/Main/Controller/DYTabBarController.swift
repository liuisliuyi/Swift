//
//  DYTabBarController.swift
//  斗鱼
//
//  Created by 汪泽煌 on 2017/2/14.
//  Copyright © 2017年 汪泽煌. All rights reserved.
//

import UIKit

class DYTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.addOneChileVC(vc: DYHomeController(), image: UIImage(named: "btn_home_normal")!, selectImage: UIImage(named: "btn_home_selected")!, title: "首页")
        self.addOneChileVC(vc: DYLiveController(), image: UIImage(named: "btn_column_normal")!, selectImage: UIImage(named: "btn_column_selected")!, title: "直播")
        self.addOneChileVC(vc: DYAttensionController(), image: UIImage(named: "btn_live_normal")!, selectImage: UIImage(named: "btn_live_selected")!, title: "关注")
        self.addOneChileVC(vc: DYProfileController(), image: UIImage(named: "btn_user_normal")!, selectImage: UIImage(named: "btn_user_selected")!, title: "我的")
        
    }

    fileprivate func addOneChileVC(vc:UIViewController,image:UIImage,selectImage:UIImage,title:String){
        
        vc.tabBarItem.image = image
        vc.tabBarItem.selectedImage = selectImage
        vc.tabBarItem.title = title;
        
        let nav = UINavigationController(rootViewController: vc)

        self.addChildViewController(nav)
        
        
    }


}
